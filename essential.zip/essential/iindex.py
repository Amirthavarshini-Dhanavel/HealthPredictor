from webapp import initialize

app = initialize()



if __name__ == '__main__':
	app.run()
